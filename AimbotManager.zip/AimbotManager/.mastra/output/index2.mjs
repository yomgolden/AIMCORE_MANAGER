import { PostgresStore } from '@mastra/pg';

const sharedPostgresStorage = new PostgresStore({
  connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra"
});

export { sharedPostgresStorage as s };
//# sourceMappingURL=index2.mjs.map
