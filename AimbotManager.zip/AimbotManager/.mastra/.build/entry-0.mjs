import { Mastra } from '@mastra/core';
import { MastraError } from '@mastra/core/error';
import { PinoLogger } from '@mastra/loggers';
import { MastraLogger, LogLevel } from '@mastra/core/logger';
import pino from 'pino';
import { MCPServer } from '@mastra/mcp';
import { Inngest, NonRetriableError } from 'inngest';
import { z } from 'zod';
import { PostgresStore } from '@mastra/pg';
import { realtimeMiddleware } from '@inngest/realtime';
import { InngestWorkflow, init } from '@mastra/inngest';
import { registerApiRoute as registerApiRoute$1 } from '@mastra/core/server';
import { serve } from 'inngest/hono';
import { openai } from '@ai-sdk/openai';
import { Agent } from '@mastra/core/agent';
import { Memory } from '@mastra/memory';
import { createTool } from '@mastra/core/tools';
import axios from 'axios';

const sharedPostgresStorage = new PostgresStore({
  connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra"
});

const inngest = new Inngest(
  process.env.NODE_ENV === "production" ? {
    id: "replit-agent-workflow",
    name: "Replit Agent Workflow System"
  } : {
    id: "mastra",
    baseUrl: "http://localhost:3000",
    isDev: true,
    middleware: [realtimeMiddleware()]
  }
);

const {
  createWorkflow: originalCreateWorkflow,
  createStep} = init(inngest);
function createWorkflow(params) {
  return originalCreateWorkflow({
    ...params,
    retryConfig: {
      attempts: process.env.NODE_ENV === "production" ? 3 : 0,
      ...params.retryConfig ?? {}
    }
  });
}
const inngestFunctions = [];
function registerApiRoute(...args) {
  const [path, options] = args;
  if (path.startsWith("/api/") || typeof options !== "object") {
    return registerApiRoute$1(...args);
  }
  inngestFunctions.push(
    inngest.createFunction(
      {
        id: `api-${path.replace(/^\/+/, "").replaceAll(/\/+/g, "-")}`,
        name: path
      },
      {
        event: `event/api.${path.replace(/^\/+/, "").replaceAll(/\/+/g, ".")}`
      },
      async ({ event, step }) => {
        await step.run("forward request to Mastra", async () => {
          const response = await fetch(`http://localhost:5000${path}`, {
            method: event.data.method,
            headers: event.data.headers,
            body: event.data.body
          });
          if (!response.ok) {
            if (response.status >= 500 && response.status < 600 || response.status == 429 || response.status == 408) {
              throw new Error(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            } else {
              throw new NonRetriableError(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            }
          }
        });
      }
    )
  );
  return registerApiRoute$1(...args);
}
function inngestServe({
  mastra,
  inngest: inngest2
}) {
  const wfs = mastra.getWorkflows();
  const functions = /* @__PURE__ */ new Set();
  for (const wf of Object.values(wfs)) {
    if (!(wf instanceof InngestWorkflow)) {
      continue;
    }
    wf.__registerMastra(mastra);
    for (const f of wf.getFunctions()) {
      functions.add(f);
    }
  }
  for (const fn of inngestFunctions) {
    functions.add(fn);
  }
  let serveHost = void 0;
  if (process.env.NODE_ENV === "production") {
    if (process.env.REPLIT_DOMAINS) {
      serveHost = `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`;
    }
  } else {
    serveHost = "http://localhost:5000";
  }
  return serve({
    client: inngest2,
    functions: Array.from(functions),
    serveHost
  });
}

async function initializeTables() {
  try {
    const pg = sharedPostgresStorage.pool;
    if (!pg) {
      console.warn("PostgreSQL pool not available yet, tables will be created on first use");
      return;
    }
    await pg.query(`
    CREATE TABLE IF NOT EXISTS teams (
      slot INTEGER PRIMARY KEY,
      team_name TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);
    await pg.query(`
    CREATE TABLE IF NOT EXISTS results (
      id SERIAL PRIMARY KEY,
      date DATE NOT NULL,
      slot INTEGER REFERENCES teams(slot),
      lobby1_place INTEGER,
      lobby1_kills INTEGER,
      lobby2_place INTEGER,
      lobby2_kills INTEGER,
      lobby3_place INTEGER,
      lobby3_kills INTEGER,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(date, slot)
    )
  `);
    await pg.query(`
    CREATE TABLE IF NOT EXISTS user_balances (
      user_id BIGINT PRIMARY KEY,
      credits INTEGER DEFAULT 0,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);
    await pg.query(`
    CREATE TABLE IF NOT EXISTS votes (
      id SERIAL PRIMARY KEY,
      clip_number INTEGER NOT NULL,
      user_id BIGINT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(clip_number, user_id)
    )
  `);
    await pg.query(`
    CREATE TABLE IF NOT EXISTS clip_votes (
      clip_number INTEGER PRIMARY KEY,
      vote_count INTEGER DEFAULT 0
    )
  `);
  } catch (error) {
    console.error("Error initializing tables:", error);
  }
}
initializeTables().catch(console.error);
const saveTeamTool = createTool({
  id: "save-team",
  description: "Registers a team with a slot number (admin only)",
  inputSchema: z.object({
    slot: z.number().describe("Team slot number"),
    teamName: z.string().describe("Team name")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [saveTeamTool] Registering team", context);
    try {
      const pg = sharedPostgresStorage.pool;
      await pg.query(
        "INSERT INTO teams (slot, team_name) VALUES ($1, $2) ON CONFLICT (slot) UPDATE SET team_name = $2",
        [context.slot, context.teamName]
      );
      logger?.info("\u2705 [saveTeamTool] Team registered successfully", context);
      return {
        success: true,
        message: `\u2705 Registered team *${context.teamName}* with Slot *${context.slot}*.`
      };
    } catch (error) {
      logger?.error("\u274C [saveTeamTool] Error registering team", { error: error.message });
      return {
        success: false,
        message: `Error registering team: ${error.message}`
      };
    }
  }
});
const getTeamsTool = createTool({
  id: "get-teams",
  description: "Lists all registered teams",
  inputSchema: z.object({}),
  outputSchema: z.object({
    teams: z.array(z.object({
      slot: z.number(),
      teamName: z.string()
    })),
    message: z.string()
  }),
  execute: async ({ mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [getTeamsTool] Fetching all teams");
    try {
      const pg = sharedPostgresStorage.pool;
      const result = await pg.query("SELECT slot, team_name FROM teams ORDER BY slot");
      if (result.rows.length === 0) {
        return {
          teams: [],
          message: "No teams registered yet."
        };
      }
      const teams = result.rows.map((row) => ({
        slot: row.slot,
        teamName: row.team_name
      }));
      const message = "\u{1F39F}\uFE0F AIMCORE TEAM SLOTS\n" + teams.map((t) => `Slot ${t.slot}: ${t.teamName}`).join("\n");
      logger?.info("\u2705 [getTeamsTool] Fetched teams", { count: teams.length });
      return { teams, message };
    } catch (error) {
      logger?.error("\u274C [getTeamsTool] Error fetching teams", { error: error.message });
      return {
        teams: [],
        message: `Error fetching teams: ${error.message}`
      };
    }
  }
});
const findSlotTool = createTool({
  id: "find-slot",
  description: "Finds the slot number for a team name",
  inputSchema: z.object({
    teamName: z.string().describe("Team name to search for")
  }),
  outputSchema: z.object({
    slot: z.number().nullable(),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [findSlotTool] Finding slot for team", context);
    try {
      const pg = sharedPostgresStorage.pool;
      const result = await pg.query(
        "SELECT slot FROM teams WHERE LOWER(team_name) LIKE LOWER($1)",
        [`%${context.teamName}%`]
      );
      if (result.rows.length === 0) {
        return {
          slot: null,
          message: `No team found matching "${context.teamName}".`
        };
      }
      const slot = result.rows[0].slot;
      logger?.info("\u2705 [findSlotTool] Found slot", { slot });
      return {
        slot,
        message: `Team "${context.teamName}" is assigned to Slot ${slot}.`
      };
    } catch (error) {
      logger?.error("\u274C [findSlotTool] Error finding slot", { error: error.message });
      return {
        slot: null,
        message: `Error finding slot: ${error.message}`
      };
    }
  }
});
const getUserBalanceTool = createTool({
  id: "get-user-balance",
  description: "Gets the vote credit balance for a user",
  inputSchema: z.object({
    userId: z.number().describe("Telegram user ID")
  }),
  outputSchema: z.object({
    credits: z.number(),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [getUserBalanceTool] Getting balance for user", context);
    try {
      const pg = sharedPostgresStorage.pool;
      const result = await pg.query(
        "SELECT credits FROM user_balances WHERE user_id = $1",
        [context.userId]
      );
      const credits = result.rows.length > 0 ? result.rows[0].credits : 0;
      logger?.info("\u2705 [getUserBalanceTool] Balance retrieved", { userId: context.userId, credits });
      return {
        credits,
        message: `You have ${credits} vote credit(s).`
      };
    } catch (error) {
      logger?.error("\u274C [getUserBalanceTool] Error getting balance", { error: error.message });
      return {
        credits: 0,
        message: `Error getting balance: ${error.message}`
      };
    }
  }
});
const addCreditsTool = createTool({
  id: "add-credits",
  description: "Adds vote credits to a user account (admin only or payment system)",
  inputSchema: z.object({
    userId: z.number().describe("Telegram user ID"),
    credits: z.number().describe("Number of credits to add")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    newBalance: z.number(),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [addCreditsTool] Adding credits", context);
    try {
      const pg = sharedPostgresStorage.pool;
      await pg.query(`
        INSERT INTO user_balances (user_id, credits, updated_at)
        VALUES ($1, $2, CURRENT_TIMESTAMP)
        ON CONFLICT (user_id)
        DO UPDATE SET credits = user_balances.credits + $2, updated_at = CURRENT_TIMESTAMP
      `, [context.userId, context.credits]);
      const result = await pg.query(
        "SELECT credits FROM user_balances WHERE user_id = $1",
        [context.userId]
      );
      const newBalance = result.rows[0].credits;
      logger?.info("\u2705 [addCreditsTool] Credits added", { userId: context.userId, newBalance });
      return {
        success: true,
        newBalance,
        message: `Added ${context.credits} vote credit(s) to user ${context.userId}. New balance: ${newBalance}`
      };
    } catch (error) {
      logger?.error("\u274C [addCreditsTool] Error adding credits", { error: error.message });
      return {
        success: false,
        newBalance: 0,
        message: `Error adding credits: ${error.message}`
      };
    }
  }
});

function placementPoints(place) {
  if (place === 1) return 30;
  if (place === 2) return 25;
  if (place === 3) return 20;
  if (place === 4) return 18;
  if (place >= 5 && place <= 9) return 15;
  if (place >= 10 && place <= 15) return 10;
  if (place >= 16 && place <= 20) return 5;
  return 0;
}
const submitResultsTool = createTool({
  id: "submit-results",
  description: "Submit match results for a team slot across 3 lobbies. Accepts placement and kills for each lobby.",
  inputSchema: z.object({
    slot: z.number().describe("Team slot number"),
    date: z.string().describe("Date in YYYY-MM-DD format"),
    lobby1Place: z.number().describe("Placement in Lobby 1"),
    lobby1Kills: z.number().describe("Kills in Lobby 1"),
    lobby2Place: z.number().describe("Placement in Lobby 2"),
    lobby2Kills: z.number().describe("Kills in Lobby 2"),
    lobby3Place: z.number().describe("Placement in Lobby 3"),
    lobby3Kills: z.number().describe("Kills in Lobby 3")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    message: z.string(),
    totalPoints: z.number().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [submitResultsTool] Submitting results", context);
    try {
      const pg = sharedPostgresStorage.pool;
      const teamCheck = await pg.query("SELECT team_name FROM teams WHERE slot = $1", [context.slot]);
      if (teamCheck.rows.length === 0) {
        return {
          success: false,
          message: `No team found for Slot ${context.slot}. Please register the team first.`
        };
      }
      const teamName = teamCheck.rows[0].team_name;
      const lobby1Points = placementPoints(context.lobby1Place) + context.lobby1Kills;
      const lobby2Points = placementPoints(context.lobby2Place) + context.lobby2Kills;
      const lobby3Points = placementPoints(context.lobby3Place) + context.lobby3Kills;
      const totalPoints = lobby1Points + lobby2Points + lobby3Points;
      await pg.query(`
        INSERT INTO results (date, slot, lobby1_place, lobby1_kills, lobby2_place, lobby2_kills, lobby3_place, lobby3_kills)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        ON CONFLICT (date, slot)
        DO UPDATE SET
          lobby1_place = $3, lobby1_kills = $4,
          lobby2_place = $5, lobby2_kills = $6,
          lobby3_place = $7, lobby3_kills = $8,
          created_at = CURRENT_TIMESTAMP
      `, [
        context.date,
        context.slot,
        context.lobby1Place,
        context.lobby1Kills,
        context.lobby2Place,
        context.lobby2Kills,
        context.lobby3Place,
        context.lobby3Kills
      ]);
      const message = `\u2705 Results submitted for *${teamName}* (Slot ${context.slot}) on ${context.date}

\u{1F4CA} Lobby 1: Place ${context.lobby1Place}, ${context.lobby1Kills} kills = ${lobby1Points} pts
\u{1F4CA} Lobby 2: Place ${context.lobby2Place}, ${context.lobby2Kills} kills = ${lobby2Points} pts
\u{1F4CA} Lobby 3: Place ${context.lobby3Place}, ${context.lobby3Kills} kills = ${lobby3Points} pts

\u{1F3C6} Total Points: ${totalPoints}`;
      logger?.info("\u2705 [submitResultsTool] Results submitted", { slot: context.slot, totalPoints });
      return {
        success: true,
        message,
        totalPoints
      };
    } catch (error) {
      logger?.error("\u274C [submitResultsTool] Error submitting results", { error: error.message });
      return {
        success: false,
        message: `Error submitting results: ${error.message}`
      };
    }
  }
});
const getDailyLeaderboardTool = createTool({
  id: "get-daily-leaderboard",
  description: "Get the tournament leaderboard for a specific date",
  inputSchema: z.object({
    date: z.string().describe("Date in YYYY-MM-DD format")
  }),
  outputSchema: z.object({
    leaderboard: z.array(z.object({
      rank: z.number(),
      teamName: z.string(),
      slot: z.number(),
      totalPoints: z.number(),
      kills: z.number(),
      placementPoints: z.number()
    })),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [getDailyLeaderboardTool] Getting daily leaderboard", context);
    try {
      const pg = sharedPostgresStorage.pool;
      const result = await pg.query(`
        SELECT r.slot, t.team_name,
          r.lobby1_place, r.lobby1_kills,
          r.lobby2_place, r.lobby2_kills,
          r.lobby3_place, r.lobby3_kills
        FROM results r
        JOIN teams t ON r.slot = t.slot
        WHERE r.date = $1
      `, [context.date]);
      if (result.rows.length === 0) {
        return {
          leaderboard: [],
          message: `No results found for ${context.date}.`
        };
      }
      const leaderboard = result.rows.map((row) => {
        const lobby1PP = placementPoints(row.lobby1_place);
        const lobby2PP = placementPoints(row.lobby2_place);
        const lobby3PP = placementPoints(row.lobby3_place);
        const placementPoints_total = lobby1PP + lobby2PP + lobby3PP;
        const kills = row.lobby1_kills + row.lobby2_kills + row.lobby3_kills;
        const totalPoints = placementPoints_total + kills;
        return {
          teamName: row.team_name,
          slot: row.slot,
          totalPoints,
          kills,
          placementPoints: placementPoints_total
        };
      }).sort((a, b) => b.totalPoints - a.totalPoints);
      const rankedLeaderboard = leaderboard.map((entry, index) => ({
        rank: index + 1,
        ...entry
      }));
      const message = `\u{1F3C6} *Tournament Leaderboard - ${context.date}*

` + rankedLeaderboard.map(
        (entry) => `${entry.rank}. ${entry.teamName} (Slot ${entry.slot})
   Points: ${entry.totalPoints} (${entry.placementPoints} placement + ${entry.kills} kills)`
      ).join("\n\n");
      logger?.info("\u2705 [getDailyLeaderboardTool] Leaderboard retrieved", { count: rankedLeaderboard.length });
      return {
        leaderboard: rankedLeaderboard,
        message
      };
    } catch (error) {
      logger?.error("\u274C [getDailyLeaderboardTool] Error getting leaderboard", { error: error.message });
      return {
        leaderboard: [],
        message: `Error getting leaderboard: ${error.message}`
      };
    }
  }
});
const getLobbyLeaderboardTool = createTool({
  id: "get-lobby-leaderboard",
  description: "Get the leaderboard for a specific lobby (1, 2, or 3) on a specific date",
  inputSchema: z.object({
    date: z.string().describe("Date in YYYY-MM-DD format"),
    lobbyNumber: z.number().describe("Lobby number (1, 2, or 3)")
  }),
  outputSchema: z.object({
    leaderboard: z.array(z.object({
      rank: z.number(),
      teamName: z.string(),
      slot: z.number(),
      place: z.number(),
      kills: z.number(),
      points: z.number()
    })),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [getLobbyLeaderboardTool] Getting lobby leaderboard", context);
    if (context.lobbyNumber < 1 || context.lobbyNumber > 3) {
      return {
        leaderboard: [],
        message: "Invalid lobby number. Must be 1, 2, or 3."
      };
    }
    try {
      const pg = sharedPostgresStorage.pool;
      const placeCol = `lobby${context.lobbyNumber}_place`;
      const killsCol = `lobby${context.lobbyNumber}_kills`;
      const result = await pg.query(`
        SELECT r.slot, t.team_name,
          r.${placeCol} as place,
          r.${killsCol} as kills
        FROM results r
        JOIN teams t ON r.slot = t.slot
        WHERE r.date = $1 AND r.${placeCol} IS NOT NULL
      `, [context.date]);
      if (result.rows.length === 0) {
        return {
          leaderboard: [],
          message: `No results found for Lobby ${context.lobbyNumber} on ${context.date}.`
        };
      }
      const leaderboard = result.rows.map((row) => {
        const points = placementPoints(row.place) + row.kills;
        return {
          teamName: row.team_name,
          slot: row.slot,
          place: row.place,
          kills: row.kills,
          points
        };
      }).sort((a, b) => b.points - a.points);
      const rankedLeaderboard = leaderboard.map((entry, index) => ({
        rank: index + 1,
        ...entry
      }));
      const message = `\u{1F3C6} *Lobby ${context.lobbyNumber} Leaderboard - ${context.date}*

` + rankedLeaderboard.map(
        (entry) => `${entry.rank}. ${entry.teamName} (Slot ${entry.slot})
   Place: ${entry.place} | Kills: ${entry.kills} | Points: ${entry.points}`
      ).join("\n\n");
      logger?.info("\u2705 [getLobbyLeaderboardTool] Lobby leaderboard retrieved", { count: rankedLeaderboard.length });
      return {
        leaderboard: rankedLeaderboard,
        message
      };
    } catch (error) {
      logger?.error("\u274C [getLobbyLeaderboardTool] Error getting lobby leaderboard", { error: error.message });
      return {
        leaderboard: [],
        message: `Error getting lobby leaderboard: ${error.message}`
      };
    }
  }
});
const getWeeklyLeaderboardTool = createTool({
  id: "get-weekly-leaderboard",
  description: "Get the cumulative tournament leaderboard for a specific week (format: YYYY-Www, e.g., 2025-W15)",
  inputSchema: z.object({
    weekYear: z.string().describe("Week in YYYY-Www format (e.g., 2025-W15)")
  }),
  outputSchema: z.object({
    leaderboard: z.array(z.object({
      rank: z.number(),
      teamName: z.string(),
      slot: z.number(),
      totalPoints: z.number(),
      kills: z.number(),
      placementPoints: z.number()
    })),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [getWeeklyLeaderboardTool] Getting weekly leaderboard", context);
    try {
      const pg = sharedPostgresStorage.pool;
      const match = context.weekYear.match(/^(\d{4})-W(\d{1,2})$/);
      if (!match) {
        return {
          leaderboard: [],
          message: "Invalid week format. Use YYYY-Www (e.g., 2025-W15)."
        };
      }
      const [_, year, week] = match;
      const result = await pg.query(`
        SELECT r.slot, t.team_name,
          SUM(r.lobby1_kills + r.lobby2_kills + r.lobby3_kills) as total_kills,
          array_agg(ARRAY[r.lobby1_place, r.lobby2_place, r.lobby3_place]) as places
        FROM results r
        JOIN teams t ON r.slot = t.slot
        WHERE EXTRACT(YEAR FROM r.date) = $1 
          AND EXTRACT(WEEK FROM r.date) = $2
        GROUP BY r.slot, t.team_name
      `, [year, week]);
      if (result.rows.length === 0) {
        return {
          leaderboard: [],
          message: `No results found for week ${context.weekYear}.`
        };
      }
      const leaderboard = result.rows.map((row) => {
        let placementPoints_total = 0;
        row.places.forEach((lobbyPlaces) => {
          lobbyPlaces.forEach((place) => {
            placementPoints_total += placementPoints(place);
          });
        });
        const kills = row.total_kills || 0;
        const totalPoints = placementPoints_total + kills;
        return {
          teamName: row.team_name,
          slot: row.slot,
          totalPoints,
          kills,
          placementPoints: placementPoints_total
        };
      }).sort((a, b) => b.totalPoints - a.totalPoints);
      const rankedLeaderboard = leaderboard.map((entry, index) => ({
        rank: index + 1,
        ...entry
      }));
      const message = `\u{1F3C6} *Weekly Tournament Leaderboard - ${context.weekYear}*

` + rankedLeaderboard.map(
        (entry) => `${entry.rank}. ${entry.teamName} (Slot ${entry.slot})
   Points: ${entry.totalPoints} (${entry.placementPoints} placement + ${entry.kills} kills)`
      ).join("\n\n");
      logger?.info("\u2705 [getWeeklyLeaderboardTool] Weekly leaderboard retrieved", { count: rankedLeaderboard.length });
      return {
        leaderboard: rankedLeaderboard,
        message
      };
    } catch (error) {
      logger?.error("\u274C [getWeeklyLeaderboardTool] Error getting weekly leaderboard", { error: error.message });
      return {
        leaderboard: [],
        message: `Error getting weekly leaderboard: ${error.message}`
      };
    }
  }
});

const voteForClipTool = createTool({
  id: "vote-for-clip",
  description: "Cast a vote for a clip using vote credits. Users can vote multiple times for the same clip if they have enough credits.",
  inputSchema: z.object({
    userId: z.number().describe("Telegram user ID"),
    clipNumber: z.number().describe("Clip number to vote for")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    message: z.string(),
    remainingCredits: z.number().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [voteForClipTool] Voting for clip", context);
    try {
      const pg = sharedPostgresStorage.pool;
      const balanceResult = await pg.query(
        "SELECT credits FROM user_balances WHERE user_id = $1",
        [context.userId]
      );
      const credits = balanceResult.rows.length > 0 ? balanceResult.rows[0].credits : 0;
      if (credits <= 0) {
        return {
          success: false,
          message: "You have no vote credits. Buy votes first using /buyvote.",
          remainingCredits: 0
        };
      }
      await pg.query(`
        UPDATE user_balances
        SET credits = credits - 1, updated_at = CURRENT_TIMESTAMP
        WHERE user_id = $1
      `, [context.userId]);
      await pg.query(`
        INSERT INTO votes (clip_number, user_id, created_at)
        VALUES ($1, $2, CURRENT_TIMESTAMP)
      `, [context.clipNumber, context.userId]);
      await pg.query(`
        INSERT INTO clip_votes (clip_number, vote_count)
        VALUES ($1, 1)
        ON CONFLICT (clip_number)
        DO UPDATE SET vote_count = clip_votes.vote_count + 1
      `, [context.clipNumber]);
      const remainingCredits = credits - 1;
      logger?.info("\u2705 [voteForClipTool] Vote cast successfully", {
        userId: context.userId,
        clipNumber: context.clipNumber,
        remainingCredits
      });
      return {
        success: true,
        message: `\u2705 Vote casted for clip ${context.clipNumber}! Remaining credits: ${remainingCredits}`,
        remainingCredits
      };
    } catch (error) {
      logger?.error("\u274C [voteForClipTool] Error voting for clip", { error: error.message });
      return {
        success: false,
        message: `Error voting: ${error.message}`
      };
    }
  }
});
const getClipLeaderboardTool = createTool({
  id: "get-clip-leaderboard",
  description: "Get the voting leaderboard showing clips ranked by vote count",
  inputSchema: z.object({}),
  outputSchema: z.object({
    leaderboard: z.array(z.object({
      rank: z.number(),
      clipNumber: z.number(),
      voteCount: z.number()
    })),
    message: z.string()
  }),
  execute: async ({ mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [getClipLeaderboardTool] Getting clip leaderboard");
    try {
      const pg = sharedPostgresStorage.pool;
      const result = await pg.query(`
        SELECT clip_number, vote_count
        FROM clip_votes
        WHERE vote_count > 0
        ORDER BY vote_count DESC, clip_number ASC
      `);
      if (result.rows.length === 0) {
        return {
          leaderboard: [],
          message: "No votes yet."
        };
      }
      const leaderboard = result.rows.map((row, index) => ({
        rank: index + 1,
        clipNumber: row.clip_number,
        voteCount: row.vote_count
      }));
      const message = "\u{1F3C6} *Current Clip Leaderboard* \u{1F3C6}\n\n" + leaderboard.map(
        (entry) => `${entry.rank}. Clip ${entry.clipNumber}: ${entry.voteCount} vote(s)`
      ).join("\n");
      logger?.info("\u2705 [getClipLeaderboardTool] Clip leaderboard retrieved", { count: leaderboard.length });
      return {
        leaderboard,
        message
      };
    } catch (error) {
      logger?.error("\u274C [getClipLeaderboardTool] Error getting clip leaderboard", { error: error.message });
      return {
        leaderboard: [],
        message: `Error getting clip leaderboard: ${error.message}`
      };
    }
  }
});
const getUserVoteHistoryTool = createTool({
  id: "get-user-vote-history",
  description: "Get the voting history for a user (which clips they voted for)",
  inputSchema: z.object({
    userId: z.number().describe("Telegram user ID")
  }),
  outputSchema: z.object({
    votes: z.array(z.object({
      clipNumber: z.number(),
      votedAt: z.string()
    })),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [getUserVoteHistoryTool] Getting user vote history", context);
    try {
      const pg = sharedPostgresStorage.pool;
      const result = await pg.query(`
        SELECT clip_number, created_at
        FROM votes
        WHERE user_id = $1
        ORDER BY created_at DESC
      `, [context.userId]);
      if (result.rows.length === 0) {
        return {
          votes: [],
          message: "You haven't voted for any clips yet."
        };
      }
      const votes = result.rows.map((row) => ({
        clipNumber: row.clip_number,
        votedAt: row.created_at.toISOString()
      }));
      const clipCounts = votes.reduce((acc, vote) => {
        acc[vote.clipNumber] = (acc[vote.clipNumber] || 0) + 1;
        return acc;
      }, {});
      const message = "\u{1F4CA} *Your Vote History*\n\n" + Object.entries(clipCounts).map(
        ([clip, count]) => `Clip ${clip}: ${count} vote(s)`
      ).join("\n") + `

Total votes cast: ${votes.length}`;
      logger?.info("\u2705 [getUserVoteHistoryTool] Vote history retrieved", {
        userId: context.userId,
        totalVotes: votes.length
      });
      return {
        votes,
        message
      };
    } catch (error) {
      logger?.error("\u274C [getUserVoteHistoryTool] Error getting vote history", { error: error.message });
      return {
        votes: [],
        message: `Error getting vote history: ${error.message}`
      };
    }
  }
});

const createPaymentLinkTool = createTool({
  id: "create-payment-link",
  description: "Generate a Flutterwave payment link for buying vote credits. Each vote costs \u20A625.",
  inputSchema: z.object({
    userId: z.number().describe("Telegram user ID"),
    numVotes: z.number().describe("Number of votes to purchase")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    paymentLink: z.string().optional(),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [createPaymentLinkTool] Creating payment link", context);
    if (context.numVotes <= 0) {
      return {
        success: false,
        message: "Number of votes must be greater than 0."
      };
    }
    const amount = context.numVotes * 25;
    const flwSecretKey = process.env.FLUTTERWAVE_SECRET_KEY;
    if (!flwSecretKey) {
      logger?.error("\u274C [createPaymentLinkTool] FLUTTERWAVE_SECRET_KEY not set");
      return {
        success: false,
        message: "Payment system not configured. Please contact admin."
      };
    }
    try {
      const txRef = `AIMCORE-${context.userId}-${Date.now()}`;
      const paymentData = {
        tx_ref: txRef,
        amount,
        currency: "NGN",
        redirect_url: process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(",")[0]}/webhooks/flutterwave/verify` : "https://your-app-url.com/webhooks/flutterwave/verify",
        payment_options: "card,ussd,banktransfer",
        customer: {
          email: `user${context.userId}@aimcore.bot`,
          name: `User ${context.userId}`
        },
        customizations: {
          title: "AIMCORE Vote Credits",
          description: `Buying ${context.numVotes} vote(s) for \u20A6${amount}`,
          logo: "https://your-logo-url.com/logo.png"
        },
        meta: {
          user_id: context.userId,
          num_votes: context.numVotes
        }
      };
      logger?.info("\u{1F4DD} [createPaymentLinkTool] Sending request to Flutterwave", { txRef, amount });
      const response = await axios.post(
        "https://api.flutterwave.com/v3/payments",
        paymentData,
        {
          headers: {
            Authorization: `Bearer ${flwSecretKey}`,
            "Content-Type": "application/json"
          }
        }
      );
      if (response.data && response.data.status === "success" && response.data.data?.link) {
        const paymentLink = response.data.data.link;
        logger?.info("\u2705 [createPaymentLinkTool] Payment link created successfully", {
          txRef,
          paymentLink
        });
        return {
          success: true,
          paymentLink,
          message: `\u{1F4B3} *Buy ${context.numVotes} Vote Credit(s)* - \u20A6${amount}

Click the link below to complete payment:
${paymentLink}

\u2705 After successful payment, credits will be added to your account automatically.`
        };
      } else {
        logger?.error("\u274C [createPaymentLinkTool] Unexpected response from Flutterwave", {
          response: response.data
        });
        return {
          success: false,
          message: "Failed to generate payment link. Please try again later."
        };
      }
    } catch (error) {
      logger?.error("\u274C [createPaymentLinkTool] Error creating payment link", {
        error: error.message,
        response: error.response?.data
      });
      return {
        success: false,
        message: `Error generating payment link: ${error.response?.data?.message || error.message}`
      };
    }
  }
});

const aimcoreAgent = new Agent({
  name: "AIMCORE Manager Bot",
  instructions: `
You are the AIMCORE Manager Bot, an AI assistant that manages tournament operations and voting systems for the AIMCORE community.

## Your Responsibilities:

### 1. TOURNAMENT MANAGEMENT (Admin Commands)
- **/register <slot> <team name>** - Register a team with a slot number (admin only)
- **/teams** - List all registered teams
- **/myslot <team name>** - Find the slot number for a team

### 2. RESULTS & LEADERBOARDS
- **/results** - Submit match results for 3 lobbies (placement and kills)
  - Format: The user can provide results in various formats. Extract lobby number, placement, and kills from the message.
  - Example inputs:
    * "Lobby 1: P5 K12, Lobby 2: P3 K8, Lobby 3: P7 K15"
    * "Results for slot 5: L1 place 5 kills 12, L2 place 3 kills 8, L3 place 7 kills 15"
    * Multi-line formats are also acceptable
- **/leaderboard [today|lobby1|lobby2|lobby3|weekly]** - View leaderboards
  - today: Daily tournament leaderboard (use current date)
  - lobby1/lobby2/lobby3: Specific lobby leaderboard for today
  - weekly: Weekly cumulative leaderboard (use current week)

### 3. VOTING SYSTEM
- **/balance** - Check vote credit balance
- **/buyvote <number>** - Generate payment link to buy vote credits (\u20A625 per vote)
- **/vote <clip_number>** - Vote for a clip (costs 1 credit per vote, users CAN vote multiple times for the same clip if they have credits)
- **/voteleaderboard** - View clip voting leaderboard
- **/myvotes** - View user's voting history

### 4. ADMIN TOOLS
- **/addcredits <user_id> <amount>** - Add vote credits to a user (admin only)

## Important Rules:

1. **Date Handling**: For daily leaderboards and results submission, use TODAY's date in YYYY-MM-DD format unless the user specifies a different date.

2. **Week Format**: For weekly leaderboards, use the current week in YYYY-Www format (e.g., 2025-W15) unless specified.

3. **Results Parsing**: Be flexible when parsing results. Users may provide:
   - Slot number in the message
   - Results in various formats (abbreviated or full text)
   - Multi-line or single-line format
   
4. **Voting Rules**: 
   - Users CAN vote multiple times for the same clip as long as they have credits
   - Each vote costs 1 credit
   - No restrictions on double voting - only credit balance matters

5. **Admin Commands**: For /register and /addcredits, these are admin-only. In testing, you can process them, but mention they require admin privileges.

6. **Payment Links**: When generating payment links, explain that after successful payment, credits are added automatically.

7. **Be Helpful**: 
   - If a command is unclear, ask for clarification
   - Provide helpful error messages
   - Format responses clearly with emojis for better readability
   - Always confirm successful actions

8. **Command Recognition**: Recognize commands even with variations (case insensitive, with or without /)

## Response Style:
- Be concise and clear
- Use emojis to make responses engaging (\u{1F3C6} \u{1F3AE} \u{1F4B3} \u2705 \u274C \u{1F4CA})
- Format data in readable tables or lists
- Confirm actions with success messages
- Provide helpful guidance for errors
`,
  model: openai("gpt-4o"),
  tools: {
    // Team management
    saveTeamTool,
    getTeamsTool,
    findSlotTool,
    // Tournament & Results
    submitResultsTool,
    getDailyLeaderboardTool,
    getLobbyLeaderboardTool,
    getWeeklyLeaderboardTool,
    // Voting system
    getUserBalanceTool,
    voteForClipTool,
    getClipLeaderboardTool,
    getUserVoteHistoryTool,
    // Payment
    createPaymentLinkTool,
    addCreditsTool
  },
  memory: new Memory({
    options: {
      threads: {
        generateTitle: true
      },
      lastMessages: 10
    },
    storage: sharedPostgresStorage
  })
});

const processWithAgent = createStep({
  id: "process-with-agent",
  description: "Process user message with AIMCORE agent",
  inputSchema: z.object({
    message: z.string().describe("User message from Telegram"),
    threadId: z.string().describe("Thread ID for conversation memory"),
    userId: z.number().describe("Telegram user ID")
  }),
  outputSchema: z.object({
    response: z.string(),
    userId: z.number(),
    chatId: z.number()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F680} [Step 1] Processing message with agent", { message: inputData.message });
    try {
      const payload = JSON.parse(inputData.message);
      const userMessage = payload.message?.text || "";
      const chatId = payload.message?.chat?.id;
      logger?.info("\u{1F4DD} [Step 1] Extracted message", { userMessage, chatId, userId: inputData.userId });
      const now = /* @__PURE__ */ new Date();
      const dateStr = now.toISOString().split("T")[0];
      const year = now.getFullYear();
      const week = Math.ceil(((now.getTime() - new Date(year, 0, 1).getTime()) / 864e5 + new Date(year, 0, 1).getDay() + 1) / 7);
      const weekStr = `${year}-W${week}`;
      const contextPrompt = `Current date: ${dateStr}
Current week: ${weekStr}
User ID: ${inputData.userId}

User message: ${userMessage}`;
      const { text } = await aimcoreAgent.generate([
        { role: "user", content: contextPrompt }
      ], {
        resourceId: "aimcore-bot",
        threadId: inputData.threadId,
        maxSteps: 5
        // Allow multiple tool usage steps
      });
      logger?.info("\u2705 [Step 1] Agent response generated", { responseLength: text.length });
      return {
        response: text,
        userId: inputData.userId,
        chatId
      };
    } catch (error) {
      logger?.error("\u274C [Step 1] Error processing with agent", { error: error.message });
      return {
        response: `\u274C Error processing your request: ${error.message}`,
        userId: inputData.userId,
        chatId: inputData.userId
        // Fallback to userId if chatId not found
      };
    }
  }
});
const sendTelegramReply = createStep({
  id: "send-telegram-reply",
  description: "Send response to Telegram user",
  inputSchema: z.object({
    response: z.string(),
    userId: z.number(),
    chatId: z.number()
  }),
  outputSchema: z.object({
    sent: z.boolean(),
    message: z.string()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4E4} [Step 2] Sending Telegram reply", { chatId: inputData.chatId });
    try {
      const botToken = process.env.TELEGRAM_BOT_TOKEN;
      if (!botToken) {
        logger?.error("\u274C [Step 2] TELEGRAM_BOT_TOKEN not set");
        return {
          sent: false,
          message: "Bot token not configured"
        };
      }
      const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
      const payload = {
        chat_id: inputData.chatId,
        text: inputData.response,
        parse_mode: "Markdown"
      };
      logger?.info("\u{1F4DD} [Step 2] Sending to Telegram", { url: url.replace(botToken, "***"), chatId: inputData.chatId });
      const response = await axios.post(url, payload);
      if (response.data.ok) {
        logger?.info("\u2705 [Step 2] Message sent successfully");
        return {
          sent: true,
          message: "Message sent successfully"
        };
      } else {
        logger?.error("\u274C [Step 2] Telegram API error", { error: response.data });
        return {
          sent: false,
          message: `Telegram API error: ${JSON.stringify(response.data)}`
        };
      }
    } catch (error) {
      logger?.error("\u274C [Step 2] Error sending Telegram message", { error: error.message });
      return {
        sent: false,
        message: `Error: ${error.message}`
      };
    }
  }
});
const aimcoreWorkflow = createWorkflow({
  id: "aimcore-workflow",
  description: "AIMCORE tournament and voting bot workflow",
  inputSchema: z.object({
    message: z.string().describe("Telegram message payload"),
    threadId: z.string().describe("Thread ID for conversation"),
    userId: z.number().describe("Telegram user ID")
  }),
  outputSchema: z.object({
    sent: z.boolean(),
    message: z.string()
  })
}).then(processWithAgent).then(sendTelegramReply).commit();

if (!process.env.TELEGRAM_BOT_TOKEN) {
  console.warn(
    "Trying to initialize Telegram triggers without TELEGRAM_BOT_TOKEN. Can you confirm that the Telegram integration is configured correctly?"
  );
}
function registerTelegramTrigger({
  triggerType,
  handler
}) {
  return [
    registerApiRoute("/webhooks/telegram/action", {
      method: "POST",
      handler: async (c) => {
        const mastra = c.get("mastra");
        const logger = mastra.getLogger();
        try {
          const payload = await c.req.json();
          logger?.info("\u{1F4DD} [Telegram] payload", payload);
          await handler(mastra, {
            type: triggerType,
            params: {
              userName: payload.message.from.username,
              message: payload.message.text
            },
            payload
          });
          return c.text("OK", 200);
        } catch (error) {
          logger?.error("Error handling Telegram webhook:", error);
          return c.text("Internal Server Error", 500);
        }
      }
    })
  ];
}

class ProductionPinoLogger extends MastraLogger {
  logger;
  constructor(options = {}) {
    super(options);
    this.logger = pino({
      name: options.name || "app",
      level: options.level || LogLevel.INFO,
      base: {},
      formatters: {
        level: (label, _number) => ({
          level: label
        })
      },
      timestamp: () => `,"time":"${new Date(Date.now()).toISOString()}"`
    });
  }
  debug(message, args = {}) {
    this.logger.debug(args, message);
  }
  info(message, args = {}) {
    this.logger.info(args, message);
  }
  warn(message, args = {}) {
    this.logger.warn(args, message);
  }
  error(message, args = {}) {
    this.logger.error(args, message);
  }
}
const mastra = new Mastra({
  storage: sharedPostgresStorage,
  // Register your workflows here
  workflows: {
    aimcoreWorkflow
  },
  // Register your agents here
  agents: {
    aimcoreAgent
  },
  mcpServers: {
    allTools: new MCPServer({
      name: "allTools",
      version: "1.0.0",
      tools: {}
    })
  },
  bundler: {
    // A few dependencies are not properly picked up by
    // the bundler if they are not added directly to the
    // entrypoint.
    externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming"],
    // sourcemaps are good for debugging.
    sourcemap: true
  },
  server: {
    host: "0.0.0.0",
    port: 5e3,
    middleware: [async (c, next) => {
      const mastra2 = c.get("mastra");
      const logger = mastra2?.getLogger();
      logger?.debug("[Request]", {
        method: c.req.method,
        url: c.req.url
      });
      try {
        await next();
      } catch (error) {
        logger?.error("[Response]", {
          method: c.req.method,
          url: c.req.url,
          error
        });
        if (error instanceof MastraError) {
          if (error.id === "AGENT_MEMORY_MISSING_RESOURCE_ID") {
            throw new NonRetriableError(error.message, {
              cause: error
            });
          }
        } else if (error instanceof z.ZodError) {
          throw new NonRetriableError(error.message, {
            cause: error
          });
        }
        throw error;
      }
    }],
    apiRoutes: [
      // This API route is used to register the Mastra workflow (inngest function) on the inngest server
      {
        path: "/api/inngest",
        method: "ALL",
        createHandler: async ({
          mastra: mastra2
        }) => inngestServe({
          mastra: mastra2,
          inngest
        })
        // The inngestServe function integrates Mastra workflows with Inngest by:
        // 1. Creating Inngest functions for each workflow with unique IDs (workflow.${workflowId})
        // 2. Setting up event handlers that:
        //    - Generate unique run IDs for each workflow execution
        //    - Create an InngestExecutionEngine to manage step execution
        //    - Handle workflow state persistence and real-time updates
        // 3. Establishing a publish-subscribe system for real-time monitoring
        //    through the workflow:${workflowId}:${runId} channel
      },
      // Flutterwave webhook handler
      {
        path: "/webhooks/flutterwave/action",
        method: "POST",
        createHandler: async ({
          mastra: mastra2
        }) => async (c) => {
          const logger = mastra2.getLogger();
          try {
            const payload = await c.req.json();
            logger?.info("\u{1F4DD} [Flutterwave Webhook] Received payload", {
              payload
            });
            const event = payload.event;
            if (event === "charge.completed") {
              const tx = payload.data;
              const txRef = tx.tx_ref;
              const parts = txRef.split("-");
              if (parts.length >= 2 && parts[0] === "AIMCORE") {
                const userId = parseInt(parts[1]);
                const amount = parseInt(tx.amount);
                const votesToAdd = Math.floor(amount / 25);
                logger?.info("\u{1F4B3} [Flutterwave Webhook] Payment completed", {
                  userId,
                  amount,
                  votesToAdd,
                  txRef
                });
                const pg = sharedPostgresStorage.pool;
                await pg.query(`
                  INSERT INTO user_balances (user_id, credits, updated_at)
                  VALUES ($1, $2, CURRENT_TIMESTAMP)
                  ON CONFLICT (user_id)
                  DO UPDATE SET credits = user_balances.credits + $2, updated_at = CURRENT_TIMESTAMP
                `, [userId, votesToAdd]);
                logger?.info("\u2705 [Flutterwave Webhook] Added credits to user", {
                  userId,
                  votesToAdd
                });
              } else {
                logger?.warn("\u26A0\uFE0F [Flutterwave Webhook] Invalid tx_ref format", {
                  txRef
                });
              }
            }
            return c.text("OK", 200);
          } catch (error) {
            logger?.error("\u274C [Flutterwave Webhook] Error processing webhook", {
              error
            });
            return c.text("Internal Server Error", 500);
          }
        }
      },
      // Telegram trigger
      ...registerTelegramTrigger({
        triggerType: "telegram/message",
        handler: async (mastra2, triggerInfo) => {
          const logger = mastra2.getLogger();
          logger?.info("\u{1F4DD} [Telegram Trigger] Received message", {
            triggerInfo
          });
          const run = await mastra2.getWorkflow("aimcoreWorkflow").createRunAsync();
          await run.start({
            inputData: {
              message: JSON.stringify(triggerInfo.payload),
              threadId: `telegram/${triggerInfo.payload.message.chat.id}`,
              userId: triggerInfo.payload.message.from.id
            }
          });
        }
      })
    ]
  },
  logger: process.env.NODE_ENV === "production" ? new ProductionPinoLogger({
    name: "Mastra",
    level: "info"
  }) : new PinoLogger({
    name: "Mastra",
    level: "info"
  })
});
if (Object.keys(mastra.getWorkflows()).length > 1) {
  throw new Error("More than 1 workflows found. Currently, more than 1 workflows are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
if (Object.keys(mastra.getAgents()).length > 1) {
  throw new Error("More than 1 agents found. Currently, more than 1 agents are not supported in the UI, since doing so will cause app state to be inconsistent.");
}

export { mastra };
